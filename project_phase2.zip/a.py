from flask import Flask, render_template,send_file, request, redirect, url_for,flash,session,jsonify,send_from_directory
import mysql.connector
import os
import jwt
import tempfile
from moviepy.editor import ImageSequenceClip
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'lalala'
UPLOAD_FOLDER='./uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER #Update this path as needed
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['JWT_SECRET_KEY'] = 'lalala'
# MySQL database connection parameters
db_config = {
    'host': 'localhost',  # Change this if your MySQL database is hosted elsewhere
    'user': 'root',
    'password': '#R08032005r',
    'database': 'dataa',
}

# Function to connect to MySQL database
def connect_to_database():
    return mysql.connector.connect(**db_config)

def generate_token(email):
    payload = {'email': email}
    return jwt.encode(payload, app.config['JWT_SECRET_KEY'], algorithm='HS256')

# Function to decode JWT token
def decode_token(token):
    try:
        payload = jwt.decode(token, app.config['JWT_SECRET_KEY'], algorithms=['HS256'])
        return payload['email']
    except jwt.ExpiredSignatureError:
        return 'Signature expired. Please log in again.'
    except jwt.InvalidTokenError:
        return 'Invalid token. Please log in again.'

def check_column_exists(column_name, table_name):
    conn = connect_to_database()
    cursor = conn.cursor()
    check_query = "SHOW COLUMNS FROM {} LIKE %s".format(table_name)
    cursor.execute(check_query, (column_name,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result is not None

# Function to add the jwt_token column to the users table if it doesn't exist
def add_jwt_token_column():
    conn = connect_to_database()
    cursor = conn.cursor()
    alter_query = "ALTER TABLE users ADD COLUMN jwt_token VARCHAR(255)"
    try:
        cursor.execute(alter_query)
        conn.commit()
        print("jwt_token column added successfully")
    except mysql.connector.Error as err:
        print(f"Error adding jwt_token column: {err}")
    finally:
        cursor.close()
        conn.close()

@app.route('/uploadimages')
def upload():
    return render_template('upload.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    if file:
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        return jsonify({'success': f'File {filename} uploaded successfully'}), 200
@app.route('/gallery')
def gallery():
    image_names = os.listdir(app.config['UPLOAD_FOLDER'])
    return render_template('gallery.html', images=image_names)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
@app.route('/create')
def createvideo():
    # Render your main HTML page here
    return render_template('createvid.html')
@app.route('/images', methods=['GET'])
def list_images():
    """
    Endpoint to list images in the UPLOAD_FOLDER.
    """
    files = [f for f in os.listdir(UPLOAD_FOLDER) if os.path.isfile(os.path.join(UPLOAD_FOLDER, f))]
    return jsonify({'images': files})
# Route for the sign page
@app.route('/uploads/<filename>ss')
def uploaded_file_create(filename):
    """
    Endpoint to serve files from the UPLOAD_FOLDER.
    """
    return send_file(os.path.join(UPLOAD_FOLDER, filename), as_attachment=True)
@app.route('/create_video', methods=['POST'])
def create_video():
    data = request.get_json()
    selected_filenames = data.get('images', [])
    image_paths = [os.path.join(UPLOAD_FOLDER, filename) for filename in selected_filenames if os.path.exists(os.path.join(UPLOAD_FOLDER, filename))]
    
    if not image_paths:
        return jsonify({'error': 'No images selected or files do not exist'}), 400

    # Create video from selected images
    clip = ImageSequenceClip(image_paths, fps=1)  # FPS can be adjusted as needed
    output_path = os.path.join(tempfile.mkdtemp(), 'created_video.mp4')
    clip.write_videofile(output_path)

    return send_file(output_path, as_attachment=True, attachment_filename='created_video.mp4')

@app.route('/', methods=['GET', 'POST'])
def sign():
    if request.method == 'POST':
        # Get form data
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        if not check_column_exists('jwt_token', 'users'):
            # If the column doesn't exist, add it to the table
            add_jwt_token_column()
        hashed_password = generate_password_hash(password)
        conn = connect_to_database()
        cursor = conn.cursor()
        # Hash the password
        check_query = "SELECT COUNT(*) FROM users WHERE email = %s"
        cursor.execute(check_query, (email,))
        result = cursor.fetchone()

        if result[0] > 0:
            # Close database connection
            cursor.close()
            conn.close()
            # Flash a message and redirect to the sign-up page
            flash("Account already exists for this email. Please login.")
            return redirect(url_for('sign'))
        token=generate_token(email)
        insert_query = "INSERT INTO users (name, email, password,jwt_token) VALUES (%s, %s, %s, %s)"
        cursor.execute(insert_query, (name, email, hashed_password,token))
        conn.commit()

        # Close database connection
        cursor.close()
        conn.close()
        flash("Account created.Login now.")
        # Redirect to the login page
        return redirect(url_for('login'))

    return render_template('sign.html')






@app.route('/home')
def home():
    username = session.get('username')  # Get the username from session
    return render_template('home.html', username=username)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Get form data
        email = request.form['email']
        password = request.form['password']
        conn = connect_to_database()
        cursor = conn.cursor()
        if email == 'admin@gmail.com' and password == 'admin1234':
            # Fetch all users for admin
            all_users_query = "SELECT * FROM users"
            cursor.execute(all_users_query)
            users = cursor.fetchall()
            cursor.close()
            conn.close()
            return render_template('admin.html', users=users)
        # Connect to MySQL database
        else:
           
       
        # Retrieve user data from database for the given email
            select_query = "SELECT id, email, name, password ,jwt_token FROM users WHERE email = %s"
            cursor.execute(select_query, (email,))
        
        # Fetch all results from the cursor
            user = cursor.fetchone()

        # Check if any user with the given email exists
            if user:
                if  check_password_hash(user[3], password):
                    if user[4]:
                        decoded_email = decode_token(user[4])
                        if decoded_email==email:
                             session['username'] = user[2]
                             session['id']=user[0]
                             session['email'] = email
                # Close database connection
                             cursor.close()
                             conn.close()
                             return redirect(url_for('home'))
                        else:
                            flash("Invalid JWT token. Please log in again.")
                            return redirect(url_for('login'))
                    else:
                        flash("JWT token not found for the user. Please log in again.")
                        return redirect(url_for('login'))
                else:
                    flash("invalid email or password")
                    return redirect(url_for('login'))
            else:
                flash("User with the provided email does not exist")
                return redirect(url_for('login'))      



    return render_template('login.html')


if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(debug=True)
