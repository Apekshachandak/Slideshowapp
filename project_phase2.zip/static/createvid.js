
let selectedImages = [];  // Array to hold selected images

document.addEventListener('DOMContentLoaded', function() {
    fetchImages();
    document.getElementById('create-video-btn').addEventListener('click', createVideo);
});

function fetchImages() {
    fetch('/images')
    .then(response => response.json())
    .then(data => {
        const imagesContainer = document.getElementById('uploaded-images');
        imagesContainer.innerHTML = ''; // Clear existing
        data.images.forEach(filename => {
            let imgDiv = document.createElement('div');
            let img = document.createElement('img');
            img.src = `uploads/${filename}`;
            img.alt = 'Uploaded Image';
            img.style.width = '100px'; // Example size, adjust as needed
            img.style.height = '100px';

            let addButton = document.createElement('button');
            addButton.textContent = 'Add to List';
            addButton.addEventListener('click', function() { addToList(filename, img.src); });

            imgDiv.appendChild(img);
            imgDiv.appendChild(addButton);
            imagesContainer.appendChild(imgDiv);
        });
    }).catch(error => console.error('Error fetching images:', error));
}

function addToList(filename, src) {
    if (!selectedImages.includes(filename)) { // Prevent duplicate entries
        selectedImages.push(filename);
        updateSelectedImagesList(src);
    }
}

function updateSelectedImagesList(src) {
    const list = document.getElementById('selected-images');
    // Instead of clearing and repopulating the list, just add the new image
    let img = document.createElement('img');
    img.src = src;
    img.alt = 'Selected Image';
    img.style.width = '100px'; // Match the size with uploaded images or as needed
    img.style.height = '100px';
    img.style.margin = '5px'; // Add some space around the images
    list.appendChild(img);
}

function createVideo() {
    fetch('/create_video', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ images: selectedImages }),
    })
    .then(response => response.blob())
    .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = 'created_video.mp4';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
    })
    .catch(error => console.error('Error creating video:', error));
}
